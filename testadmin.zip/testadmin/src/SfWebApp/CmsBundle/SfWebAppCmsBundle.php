<?php

namespace SfWebApp\CmsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SfWebAppCmsBundle extends Bundle
{
}
