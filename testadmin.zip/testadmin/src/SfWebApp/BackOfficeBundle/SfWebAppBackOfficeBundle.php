<?php

namespace SfWebApp\BackOfficeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SfWebAppBackOfficeBundle extends Bundle
{
}
