<?php

namespace SfWebApp\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SfWebAppMainBundle extends Bundle
{
}
