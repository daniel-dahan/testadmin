<?php

/* SfWebAppCmsBundle:Default:index.html.twig */
class __TwigTemplate_cab899d49f07777d9b1f7953bcb8f098e96ca4d901818e1de65e84a7298456b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b6024385160ddbc06a5c2e37b6852c780e2cbbeb630eb345a2528e958d3dd65f = $this->env->getExtension("native_profiler");
        $__internal_b6024385160ddbc06a5c2e37b6852c780e2cbbeb630eb345a2528e958d3dd65f->enter($__internal_b6024385160ddbc06a5c2e37b6852c780e2cbbeb630eb345a2528e958d3dd65f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SfWebAppCmsBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_b6024385160ddbc06a5c2e37b6852c780e2cbbeb630eb345a2528e958d3dd65f->leave($__internal_b6024385160ddbc06a5c2e37b6852c780e2cbbeb630eb345a2528e958d3dd65f_prof);

    }

    public function getTemplateName()
    {
        return "SfWebAppCmsBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
